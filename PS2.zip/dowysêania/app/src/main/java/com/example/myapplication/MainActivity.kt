package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var questionTextView: TextView
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var nextButton: Button
    private lateinit var hintButton: Button

    private val questionBank = listOf(
        Question(R.string.q1, true),
        Question(R.string.q2, true),
        Question(R.string.q3, false),
        Question(R.string.q4, true),
        Question(R.string.q5, true)
    )

    private var currentIndex = 0
    private var correctAnswers = 0
    private var answerWasShown = false
    private var answeredQuestions = 0 // licznik udzielonych odpowiedzi

    companion object {
        private const val TAG = "MainActivity"
        private const val KEY_INDEX = "index"
        private const val KEY_SCORE = "score"
        private const val KEY_ANSWERED = "answered"
    }


    private val promptActivityLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            answerWasShown = data?.getBooleanExtra("EXTRA_ANSWER_SHOWN", false) ?: false
        }
    }

    // --- CYKL ŻYCIA ---
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(TAG, "onCreate()")

        currentIndex = savedInstanceState?.getInt(KEY_INDEX, 0) ?: 0
        correctAnswers = savedInstanceState?.getInt(KEY_SCORE, 0) ?: 0
        answeredQuestions = savedInstanceState?.getInt(KEY_ANSWERED, 0) ?: 0

        questionTextView = findViewById(R.id.question_text_view)
        trueButton = findViewById(R.id.true_button)
        falseButton = findViewById(R.id.false_button)
        nextButton = findViewById(R.id.next_button)
        hintButton = findViewById(R.id.hint_button)

        updateQuestion()

        trueButton.setOnClickListener {
            if (answerWasShown) {
                Toast.makeText(this, "Użyto podpowiedzi!", Toast.LENGTH_SHORT).show()
            } else checkAnswer(true)
        }

        falseButton.setOnClickListener {
            if (answerWasShown) {
                Toast.makeText(this, "Użyto podpowiedzi!", Toast.LENGTH_SHORT).show()
            } else checkAnswer(false)
        }

        nextButton.setOnClickListener {
            if (answeredQuestions == questionBank.size) {
                Toast.makeText(
                    this,
                    "Twój wynik: $correctAnswers / ${questionBank.size}",
                    Toast.LENGTH_LONG
                ).show()
                resetQuiz()
            } else {
                currentIndex = (currentIndex + 1) % questionBank.size
                answerWasShown = false
                updateQuestion()
            }
        }

        hintButton.setOnClickListener {
            val answerIsTrue = questionBank[currentIndex].answer
            val intent = Intent(this, PromptActivity::class.java)
            intent.putExtra("EXTRA_ANSWER", answerIsTrue)
            promptActivityLauncher.launch(intent)
        }
    }

    private fun resetQuiz() {
        currentIndex = 0
        correctAnswers = 0
        answeredQuestions = 0
        answerWasShown = false
        updateQuestion()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_INDEX, currentIndex)
        outState.putInt(KEY_SCORE, correctAnswers)
        outState.putInt(KEY_ANSWERED, answeredQuestions)
    }

    private fun updateQuestion() {
        val question = questionBank[currentIndex]
        questionTextView.setText(question.textResId)
    }

    private fun checkAnswer(userAnswer: Boolean) {
        val correctAnswer = questionBank[currentIndex].answer
        answeredQuestions++

        val messageResId = if (userAnswer == correctAnswer) {
            correctAnswers++
            "Poprawna odpowiedź!"
        } else {
            "Błąd!"
        }

        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show()


        if (answeredQuestions < questionBank.size) {
            currentIndex = (currentIndex + 1) % questionBank.size
            answerWasShown = false
            updateQuestion()
        } else {
            Toast.makeText(
                this,
                "Koniec quizu! Twój wynik: $correctAnswers / ${questionBank.size}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}


