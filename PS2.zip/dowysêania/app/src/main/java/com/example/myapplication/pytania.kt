package com.example.myapplication


data class Question(
    val textResId: Int,
    val answer: Boolean
)

