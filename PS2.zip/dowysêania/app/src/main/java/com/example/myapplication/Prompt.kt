package com.example.myapplication



import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PromptActivity : AppCompatActivity() {

    private lateinit var showAnswerButton: Button
    private lateinit var answerTextView: TextView
    private lateinit var backButton: Button

    private var answerIsTrue: Boolean = false
    private var answerWasShown: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prompt)

        showAnswerButton = findViewById(R.id.show_answer_button)
        answerTextView = findViewById(R.id.answer_text_view)
        backButton = findViewById(R.id.back_button)

        // Odczytujemy przesłaną wartość z intencji
        answerIsTrue = intent.getBooleanExtra("EXTRA_ANSWER", false)

        showAnswerButton.setOnClickListener {
            val answerText = if (answerIsTrue) "Prawda" else "Fałsz"
            answerTextView.text = answerText
            answerWasShown = true
        }

        // 🟢 Po kliknięciu „Wróć” wracamy do MainActivity
        backButton.setOnClickListener {
            val data = Intent()
            data.putExtra("EXTRA_ANSWER_SHOWN", answerWasShown)
            setResult(Activity.RESULT_OK, data)
            finish() // zamyka PromptActivity i wraca do MainActivity
        }
    }
}
